#include<stdio.h>
int main()
{
    int a,b;
    int max = 0;
    int cnt = 0;
    
    int i;
    for(i=0;i<7;i++)
    {
        scanf("%d %d",&a,&b);
        if(a+b>max)
        {
            max = a+b;
            
            cnt = i+1;
        }
    }
    
    printf("%d",cnt);
    
    return 0;

}